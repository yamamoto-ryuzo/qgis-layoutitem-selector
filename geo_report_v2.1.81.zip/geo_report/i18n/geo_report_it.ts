<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="it">
  <context>
    <name>geo_report</name>
    <message>
      <source>  Page </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>All Objects List:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Angle:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Apply Properties</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Available Layout Property Files:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Browse Other Folder...</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Cannot load properties: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Create Report</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Display Name</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Error getting information</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Folder: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Font Size</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Height (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Hello</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Hide Print Area</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>ID</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Image Path</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Import failed</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Information</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Item Name</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Item Properties</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Item information has been updated.</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Layout Info</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Layout Information:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Layout Items:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Layout List:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Layout Name: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Layout Selection &amp; Item Management</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Load Layout</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Modified</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Page Count: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Page Information:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Please select a layout.</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Print area moved.</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Refresh Item Info</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Rotation Angle</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Save Layout</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Scale</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Scale:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Select</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Select Layout Property File</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Selected Item Properties:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Show Print Area on Map</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Size</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Text</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Total Objects: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Type</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Visible</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Warning</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Width (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>X Position (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Y Position (mm)</source>
      <translation type="unfinished"/>
    </message>
  </context>
</TS>
