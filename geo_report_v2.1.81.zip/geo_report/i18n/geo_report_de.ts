<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="de">
  <context>
    <name>geo_report</name>
    <message>
      <source>  Page </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>All Objects List:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Angle:</source>
    <translation>Winkel:</translation>
    </message>
    <message>
      <source>Apply Properties</source>
    <translation>Eigenschaften anwenden</translation>
    </message>
    <message>
      <source>Available Layout Property Files:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Browse Other Folder...</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Cannot load properties: </source>
    <translation>Eigenschaften können nicht geladen werden: </translation>
    </message>
    <message>
      <source>Create Report</source>
    <translation>Bericht erstellen</translation>
    </message>
    <message>
      <source>Display Name</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Error</source>
    <translation>Fehler</translation>
    </message>
    <message>
      <source>Error getting information</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Folder: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Font Size</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Height (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Hello</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Hide Print Area</source>
    <translation>Druckbereich ausblenden</translation>
    </message>
    <message>
      <source>ID</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Image Path</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Import failed</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Information</source>
    <translation>Information</translation>
    </message>
    <message>
      <source>Item Name</source>
    <translation>Elementname</translation>
    </message>
    <message>
      <source>Item Properties</source>
    <translation>Elementeigenschaften</translation>
    </message>
    <message>
      <source>Item information has been updated.</source>
    <translation>Elementinformationen wurden aktualisiert.</translation>
    </message>
    <message>
      <source>Layout Info</source>
    <translation>Layout-Info</translation>
    </message>
    <message>
      <source>Layout Information:</source>
    <translation>Layout-Informationen:</translation>
    </message>
    <message>
      <source>Layout Items:</source>
    <translation>Layout-Elemente:</translation>
    </message>
    <message>
      <source>Layout List:</source>
    <translation>Layout-Liste:</translation>
    </message>
    <message>
      <source>Layout Name: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Layout Selection &amp; Item Management</source>
    <translation>Layout-Auswahl und Elementverwaltung</translation>
    </message>
    <message>
      <source>Load Layout</source>
    <translation>Layout laden</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Page Count: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Page Information:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Please select a layout.</source>
    <translation>Bitte wählen Sie ein Layout aus.</translation>
    </message>
    <message>
      <source>Print area moved.</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Refresh Item Info</source>
    <translation>Elementinformationen aktualisieren</translation>
    </message>
    <message>
      <source>Rotation Angle</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Save Layout</source>
    <translation>Layout speichern</translation>
    </message>
    <message>
      <source>Scale</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Scale:</source>
    <translation>Maßstab:</translation>
    </message>
    <message>
      <source>Select</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Select Layout Property File</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Selected Item Properties:</source>
    <translation>Eigenschaften des ausgewählten Elements:</translation>
    </message>
    <message>
      <source>Show Print Area on Map</source>
    <translation>Druckbereich auf Karte anzeigen</translation>
    </message>
    <message>
      <source>Size</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Text</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Total Objects: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Type</source>
    <translation>Typ</translation>
    </message>
    <message>
      <source>Visible</source>
    <translation>Sichtbar</translation>
    </message>
    <message>
      <source>Warning</source>
    <translation>Warnung</translation>
    </message>
    <message>
      <source>Width (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>X Position (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Y Position (mm)</source>
      <translation type="unfinished"/>
    </message>
  </context>
</TS>
