<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="en">
  <context>
    <name>geo_report</name>
    <message>
      <source>  Page </source>
      <translation type="unfinished">  Page </translation>
    </message>
    <message>
      <source>All Objects List:</source>
      <translation type="unfinished">All Objects List:</translation>
    </message>
    <message>
      <source>Angle:</source>
      <translation type="unfinished">Angle:</translation>
    </message>
    <message>
      <source>Apply Properties</source>
      <translation type="unfinished">Apply Properties</translation>
    </message>
    <message>
      <source>Available Layout Property Files:</source>
      <translation type="unfinished">Available Layout Property Files:</translation>
    </message>
    <message>
      <source>Browse Other Folder...</source>
      <translation type="unfinished">Browse Other Folder...</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Cannot load properties: </source>
      <translation type="unfinished">Cannot load properties: </translation>
    </message>
    <message>
      <source>Create Report</source>
      <translation type="unfinished">Create Report</translation>
    </message>
    <message>
      <source>Display Name</source>
      <translation type="unfinished">Display Name</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Error getting information</source>
      <translation type="unfinished">Error getting information</translation>
    </message>
    <message>
      <source>Folder: </source>
      <translation type="unfinished">Folder: </translation>
    </message>
    <message>
      <source>Font Size</source>
      <translation type="unfinished">Font Size</translation>
    </message>
    <message>
      <source>Height (mm)</source>
      <translation type="unfinished">Height (mm)</translation>
    </message>
    <message>
      <source>Hello</source>
      <translation type="unfinished">Hello</translation>
    </message>
    <message>
      <source>Hide Print Area</source>
      <translation type="unfinished">Hide Print Area</translation>
    </message>
    <message>
      <source>ID</source>
      <translation type="unfinished">ID</translation>
    </message>
    <message>
      <source>Image Path</source>
      <translation type="unfinished">Image Path</translation>
    </message>
    <message>
      <source>Import failed</source>
      <translation type="unfinished">Import failed</translation>
    </message>
    <message>
      <source>Information</source>
      <translation type="unfinished">Information</translation>
    </message>
    <message>
      <source>Item Name</source>
      <translation type="unfinished">Item Name</translation>
    </message>
    <message>
      <source>Item Properties</source>
      <translation type="unfinished">Item Properties</translation>
    </message>
    <message>
      <source>Item information has been updated.</source>
      <translation type="unfinished">Item information has been updated.</translation>
    </message>
    <message>
      <source>Layout Info</source>
      <translation type="unfinished">Layout Info</translation>
    </message>
    <message>
      <source>Layout Information:</source>
      <translation type="unfinished">Layout Information:</translation>
    </message>
    <message>
      <source>Layout Items:</source>
      <translation type="unfinished">Layout Items:</translation>
    </message>
    <message>
      <source>Layout List:</source>
      <translation type="unfinished">Layout List:</translation>
    </message>
    <message>
      <source>Layout Name: </source>
      <translation type="unfinished">Layout Name: </translation>
    </message>
    <message>
      <source>Layout Selection &amp; Item Management</source>
      <translation type="unfinished">Layout Selection &amp; Item Management</translation>
    </message>
    <message>
      <source>Load Layout</source>
      <translation type="unfinished">Load Layout</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation type="unfinished">Modified</translation>
    </message>
    <message>
      <source>Page Count: </source>
      <translation type="unfinished">Page Count: </translation>
    </message>
    <message>
      <source>Page Information:</source>
      <translation type="unfinished">Page Information:</translation>
    </message>
    <message>
      <source>Please select a layout.</source>
      <translation type="unfinished">Please select a layout.</translation>
    </message>
    <message>
      <source>Print area moved.</source>
      <translation type="unfinished">Print area moved.</translation>
    </message>
    <message>
      <source>Refresh Item Info</source>
      <translation type="unfinished">Refresh Item Info</translation>
    </message>
    <message>
      <source>Rotation Angle</source>
      <translation type="unfinished">Rotation Angle</translation>
    </message>
    <message>
      <source>Save Layout</source>
      <translation type="unfinished">Save Layout</translation>
    </message>
    <message>
      <source>Scale</source>
      <translation type="unfinished">Scale</translation>
    </message>
    <message>
      <source>Scale:</source>
      <translation type="unfinished">Scale:</translation>
    </message>
    <message>
      <source>Select</source>
      <translation type="unfinished">Select</translation>
    </message>
    <message>
      <source>Select Layout Property File</source>
      <translation type="unfinished">Select Layout Property File</translation>
    </message>
    <message>
      <source>Selected Item Properties:</source>
      <translation type="unfinished">Selected Item Properties:</translation>
    </message>
    <message>
      <source>Show Print Area on Map</source>
      <translation type="unfinished">Show Print Area on Map</translation>
    </message>
    <message>
      <source>Size</source>
      <translation type="unfinished">Size</translation>
    </message>
    <message>
      <source>Text</source>
      <translation type="unfinished">Text</translation>
    </message>
    <message>
      <source>Total Objects: </source>
      <translation type="unfinished">Total Objects: </translation>
    </message>
    <message>
      <source>Type</source>
      <translation type="unfinished">Type</translation>
    </message>
    <message>
      <source>Visible</source>
      <translation type="unfinished">Visible</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation type="unfinished">Warning</translation>
    </message>
    <message>
      <source>Width (mm)</source>
      <translation type="unfinished">Width (mm)</translation>
    </message>
    <message>
      <source>X Position (mm)</source>
      <translation type="unfinished">X Position (mm)</translation>
    </message>
    <message>
      <source>Y Position (mm)</source>
      <translation type="unfinished">Y Position (mm)</translation>
    </message>
  </context>
</TS>
