<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="zh">
  <context>
    <name>geo_report</name>
    <message>
      <source>  Page </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>All Objects List:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Angle:</source>
    <translation>角度:</translation>
    </message>
    <message>
      <source>Apply Properties</source>
    <translation>应用属性</translation>
    </message>
    <message>
      <source>Available Layout Property Files:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Browse Other Folder...</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Cannot load properties: </source>
    <translation>无法加载属性: </translation>
    </message>
    <message>
      <source>Create Report</source>
    <translation>创建报告</translation>
    </message>
    <message>
      <source>Display Name</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Error</source>
    <translation>错误</translation>
    </message>
    <message>
      <source>Error getting information</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Folder: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Font Size</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Height (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Hello</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Hide Print Area</source>
    <translation>隐藏打印区域</translation>
    </message>
    <message>
      <source>ID</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Image Path</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Import failed</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Information</source>
    <translation>信息</translation>
    </message>
    <message>
      <source>Item Name</source>
    <translation>项目名称</translation>
    </message>
    <message>
      <source>Item Properties</source>
    <translation>项目属性</translation>
    </message>
    <message>
      <source>Item information has been updated.</source>
    <translation>项目信息已更新。</translation>
    </message>
    <message>
      <source>Layout Info</source>
    <translation>布局信息</translation>
    </message>
    <message>
      <source>Layout Information:</source>
    <translation>布局信息:</translation>
    </message>
    <message>
      <source>Layout Items:</source>
    <translation>布局项目:</translation>
    </message>
    <message>
      <source>Layout List:</source>
    <translation>布局列表:</translation>
    </message>
    <message>
      <source>Layout Name: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Layout Selection &amp; Item Management</source>
    <translation>布局选择和项目管理</translation>
    </message>
    <message>
      <source>Load Layout</source>
    <translation>加载布局</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Page Count: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Page Information:</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Please select a layout.</source>
    <translation>请选择一个布局。</translation>
    </message>
    <message>
      <source>Print area moved.</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Refresh Item Info</source>
    <translation>刷新项目信息</translation>
    </message>
    <message>
      <source>Rotation Angle</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Save Layout</source>
    <translation>保存布局</translation>
    </message>
    <message>
      <source>Scale</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Scale:</source>
    <translation>比例:</translation>
    </message>
    <message>
      <source>Select</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Select Layout Property File</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Selected Item Properties:</source>
    <translation>所选项目属性:</translation>
    </message>
    <message>
      <source>Show Print Area on Map</source>
    <translation>在地图上显示打印区域</translation>
    </message>
    <message>
      <source>Size</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Text</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Total Objects: </source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Type</source>
    <translation>类型</translation>
    </message>
    <message>
      <source>Visible</source>
    <translation>可见</translation>
    </message>
    <message>
      <source>Warning</source>
    <translation>警告</translation>
    </message>
    <message>
      <source>Width (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>X Position (mm)</source>
      <translation type="unfinished"/>
    </message>
    <message>
      <source>Y Position (mm)</source>
      <translation type="unfinished"/>
    </message>
  </context>
</TS>
