<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="ru_RU">
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="14" />
        <source>Layout Item Selector - geo_report</source>
        <translation>Выбор элемента компоновки - geo_report</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="23" />
        <source>Layout List:</source>
        <translation>Список компоновок:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="35" />
        <source>Scale:</source>
        <translation>Масштаб:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="62" />
        <source>Angle:</source>
        <translation>Угол:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="89" />
        <source>Show Print Area on Map</source>
        <translation>Показать область печати на карте</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="99" />
        <source>Open Layout Manager</source>
        <translation>Открыть менеджер компоновок</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="109" />
        <source>Refresh Item Info</source>
        <translation>Обновить информацию об элементе</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="119" />
        <source>Save Layout</source>
        <translation>Сохранить компоновку</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="129" />
        <source>Load Layout</source>
        <translation>Загрузить компоновку</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="139" />
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="174" />
        <source>Layout Items:</source>
        <translation>Элементы компоновки:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="182" />
        <source>Item Name</source>
        <translation>Имя элемента</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="187" />
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="192" />
        <source>Visible</source>
        <translation>Видимый</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="202" />
        <source>Item Properties</source>
        <translation>Свойства элемента</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="208" />
        <source>Selected Item Properties:</source>
        <translation>Свойства выбранного элемента:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="227" />
        <source>Apply Properties</source>
        <translation>Применить свойства</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="237" />
        <source>Layout Info</source>
        <translation>Информация о компоновке</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="243" />
        <source>Layout Information:</source>
        <translation>Информация о компоновке:</translation>
    </message>
</context>
</TS>