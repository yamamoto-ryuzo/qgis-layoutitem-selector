<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="hi">
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../ui/main_dialog.ui" line="14" />
        <source>Layout Item Selector - geo_report</source>
        <translation>लेआउट आइटम चयनकर्ता - geo_report</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="23" />
        <source>Layout List:</source>
        <translation>लेआउट सूची:</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="35" />
        <source>Scale:</source>
        <translation>स्केल:</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="62" />
        <source>Angle:</source>
        <translation>कोण:</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="89" />
        <source>Show Print Area on Map</source>
        <translation>नक्शे पर प्रिंट क्षेत्र दिखाएँ</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="99" />
        <source>Open Layout Manager</source>
        <translation>लेआउट प्रबंधक खोलें</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="109" />
        <source>Refresh Item Info</source>
        <translation>आइटम जानकारी ताज़ा करें</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="119" />
        <source>Save Layout</source>
        <translation>लेआउट सहेजें</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="129" />
        <source>Load Layout</source>
        <translation>लेआउट लोड करें</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="139" />
        <source>Cancel</source>
        <translation>रद्द करें</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="174" />
        <source>Layout Items:</source>
        <translation>लेआउट आइटम:</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="182" />
        <source>Item Name</source>
        <translation>आइटम नाम</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="187" />
        <source>Type</source>
        <translation>प्रकार</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="192" />
        <source>Visible</source>
        <translation>दृश्यमान</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="202" />
        <source>Item Properties</source>
        <translation>आइटम गुण</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="208" />
        <source>Selected Item Properties:</source>
        <translation>चयनित आइटम गुण:</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="227" />
        <source>Apply Properties</source>
        <translation>गुण लागू करें</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="237" />
        <source>Layout Info</source>
        <translation>लेआउट जानकारी</translation>
    </message>
    <message>
        <location filename="../ui/main_dialog.ui" line="243" />
        <source>Layout Information:</source>
        <translation>लेआउट जानकारी:</translation>
    </message>
</context>
</TS>