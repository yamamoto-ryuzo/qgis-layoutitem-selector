# -*- coding: utf-8 -*-
"""
UI モジュール

Qt Designer で作成した UI ファイルとローダーを提供。
"""
