<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="it_IT">
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="14" />
        <source>Layout Item Selector - geo_report</source>
        <translation>Selettore elementi layout - geo_report</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="23" />
        <source>Layout List:</source>
        <translation>Elenco layout:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="35" />
        <source>Scale:</source>
        <translation>Scala:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="62" />
        <source>Angle:</source>
        <translation>Angolo:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="89" />
        <source>Show Print Area on Map</source>
        <translation>Mostra area di stampa sulla mappa</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="99" />
        <source>Open Layout Manager</source>
        <translation>Apri gestore layout</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="109" />
        <source>Refresh Item Info</source>
        <translation>Aggiorna informazioni elemento</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="119" />
        <source>Save Layout</source>
        <translation>Salva layout</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="129" />
        <source>Load Layout</source>
        <translation>Carica layout</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="139" />
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="174" />
        <source>Layout Items:</source>
        <translation>Elementi del layout:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="182" />
        <source>Item Name</source>
        <translation>Nome elemento</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="187" />
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="192" />
        <source>Visible</source>
        <translation>Visibile</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="202" />
        <source>Item Properties</source>
        <translation>Proprietà elemento</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="208" />
        <source>Selected Item Properties:</source>
        <translation>Proprietà dell'elemento selezionato:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="227" />
        <source>Apply Properties</source>
        <translation>Applica proprietà</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="237" />
        <source>Layout Info</source>
        <translation>Info layout</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="243" />
        <source>Layout Information:</source>
        <translation>Informazioni sul layout:</translation>
    </message>
</context>
</TS>