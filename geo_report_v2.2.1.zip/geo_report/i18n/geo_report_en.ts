<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="14"/>
        <source>Layout Item Selector - geo_report</source>
        <translation>Layout Item Selector - geo_report</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="23"/>
        <source>Layout List:</source>
        <translation>Layout List:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="35"/>
        <source>Scale:</source>
        <translation>Scale:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="62"/>
        <source>Angle:</source>
        <translation>Angle:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="89"/>
        <source>Show Print Area on Map</source>
        <translation>Show Print Area on Map</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="99"/>
        <source>Open Layout Manager</source>
        <translation>Open Layout Manager</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="109"/>
        <source>Refresh Item Info</source>
        <translation>Refresh Item Info</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="119"/>
        <source>Save Layout</source>
        <translation>Save Layout</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="129"/>
        <source>Load Layout</source>
        <translation>Load Layout</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="139"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="174"/>
        <source>Layout Items:</source>
        <translation>Layout Items:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="182"/>
        <source>Item Name</source>
        <translation>Item Name</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="187"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="192"/>
        <source>Visible</source>
        <translation>Visible</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="202"/>
        <source>Item Properties</source>
        <translation>Item Properties</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="208"/>
        <source>Selected Item Properties:</source>
        <translation>Selected Item Properties:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="227"/>
        <source>Apply Properties</source>
        <translation>Apply Properties</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="237"/>
        <source>Layout Info</source>
        <translation>Layout Info</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="243"/>
        <source>Layout Information:</source>
        <translation>Layout Information:</translation>
    </message>
</context>
</TS>
