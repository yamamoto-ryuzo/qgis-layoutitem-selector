<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="de_DE">
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="14" />
        <source>Layout Item Selector - geo_report</source>
        <translation>Layout-Element-Auswahl - geo_report</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="23" />
        <source>Layout List:</source>
        <translation>Layout-Liste:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="35" />
        <source>Scale:</source>
        <translation>Maßstab:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="62" />
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="89" />
        <source>Show Print Area on Map</source>
        <translation>Druckbereich auf Karte anzeigen</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="99" />
        <source>Open Layout Manager</source>
        <translation>Layoutmanager öffnen</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="109" />
        <source>Refresh Item Info</source>
        <translation>Elementinformationen aktualisieren</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="119" />
        <source>Save Layout</source>
        <translation>Layout speichern</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="129" />
        <source>Load Layout</source>
        <translation>Layout laden</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="139" />
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="174" />
        <source>Layout Items:</source>
        <translation>Layout-Elemente:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="182" />
        <source>Item Name</source>
        <translation>Elementname</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="187" />
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="192" />
        <source>Visible</source>
        <translation>Sichtbar</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="202" />
        <source>Item Properties</source>
        <translation>Elementeigenschaften</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="208" />
        <source>Selected Item Properties:</source>
        <translation>Ausgewählte Elementeigenschaften:</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="227" />
        <source>Apply Properties</source>
        <translation>Eigenschaften anwenden</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="237" />
        <source>Layout Info</source>
        <translation>Layout-Informationen</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="243" />
        <source>Layout Information:</source>
        <translation>Layout-Informationen:</translation>
    </message>
</context>
</TS>