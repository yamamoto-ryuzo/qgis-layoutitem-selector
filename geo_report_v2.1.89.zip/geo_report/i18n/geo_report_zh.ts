<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="zh_CN">
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="14" />
        <source>Layout Item Selector - geo_report</source>
        <translation>布局项选择器 - geo_report</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="23" />
        <source>Layout List:</source>
        <translation>布局列表：</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="35" />
        <source>Scale:</source>
        <translation>比例：</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="62" />
        <source>Angle:</source>
        <translation>角度：</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="89" />
        <source>Show Print Area on Map</source>
        <translation>在地图上显示打印区域</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="99" />
        <source>Open Layout Manager</source>
        <translation>打开布局管理器</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="109" />
        <source>Refresh Item Info</source>
        <translation>刷新项目信息</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="119" />
        <source>Save Layout</source>
        <translation>保存布局</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="129" />
        <source>Load Layout</source>
        <translation>加载布局</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="139" />
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="174" />
        <source>Layout Items:</source>
        <translation>布局项：</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="182" />
        <source>Item Name</source>
        <translation>项名称</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="187" />
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="192" />
        <source>Visible</source>
        <translation>可见</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="202" />
        <source>Item Properties</source>
        <translation>项属性</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="208" />
        <source>Selected Item Properties:</source>
        <translation>所选项属性：</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="227" />
        <source>Apply Properties</source>
        <translation>应用属性</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="237" />
        <source>Layout Info</source>
        <translation>布局信息</translation>
    </message>
    <message>
        <location filename="../geo_report/ui/main_dialog.ui" line="243" />
        <source>Layout Information:</source>
        <translation>布局信息：</translation>
    </message>
</context>
</TS>